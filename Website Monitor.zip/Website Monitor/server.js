const fs = require("fs");
const moment = require("moment");

const config = JSON.parse(fs.readFileSync("./config.json"));
const Discord = require('discord.js');
const client = new Discord.Client();

let MESSAGE;

// load enabled components
const component_names = fs.readdirSync('./components/');
const components = new Map();
component_names.forEach(file_name => {
	if (!file_name.endsWith('.js')) return;

	const file = require(`./components/${file_name}`);

	const component_name = file_name.split('.js').join('');

	if (config.components[component_name])
		components.set(component_name, file);
});

async function update() {
	if (!MESSAGE) return console.log('Unable to fetch channel or message.');

	let payload = '';

	if (config.title != ""){
		payload += `\n__**${config.title}**__\n`;
	}

	const promises = [];
	components.forEach(component => promises.push(component.update()));

	const values = await Promise.all(promises);
	payload += values.join('\n');

	switch (config.displayTimestamp) {
		case false:
			break;
		case "12h": case "12": case "": case true:
			payload += `\n:timer: **Last Updated:** ${moment().format("hh:mm:ss A DD-MM-YYYY")} `;
			break;
		case "24h": case "24":
			payload += `\n:timer: **Last Updated:** ${moment().format("HH:mm:ss DD-MM-YYYY")} `;
			break;
		default:
			console.error('Invalid displayTimestamp config value.');
			break;
	}

	MESSAGE.edit(payload);
	setTimeout(update, config.interval * 1000);
}

client.on('ready', async () => {
	if (config.activityDisplay == true){
		client.user.setPresence({ activity: { name: 'RapiiCloud.ddns.net' }, status: 'playing' })
	}
	console.log(`Logged in as ${client.user.tag} !`);

	if (config.messageID && config.channelID) {
		let channel = await client.channels.fetch(config.channelID);
		MESSAGE = await channel.messages.fetch(config.messageID);
		console.log(`Updating every ${config.interval}s...`);
		update();
	} else {
		console.log("$start For Monitoring");
	}
});

client.on('message', async (message) => {
	if (message.author.bot) return;
	if (message.content === '$start') {
		if (config.messageID) return message.reply("stats has already started.");

		let msg = await message.channel.send("Updatig stats...");
		config.messageID = msg.id;
		config.channelID = msg.channel.id;
		MESSAGE = msg;
		fs.writeFileSync('./config.json', JSON.stringify(config, null, 2));
		update();
	}
	if (message.content === '$ping') {
		const msg = await message.channel.send('Ping?')
		msg.edit(`Pong! Latency is ${Math.round(msg.createdTimestamp - message.createdTimestamp)} ms. API Latency is ${Math.round(client.ws.ping)} ms`)
	}
	if (message.content === '$help') {
		const help = [
			'Welcome to Website Monitor',
			'',
			'Here are the list of commands: ',
			'`$ping` - shows my latency',
			'`$start` - start updating the stats',
			'`$help` - shows this message',
			'',
			'About me',
			'Source Bot 12Dls',
			'For suggestions or bugs join my support server - https://discord.gg/gxZd7jgRz6'
		].join('\n');
		return message.channel.send(help);
	}
});

try {
	console.log("Starting PC STAT BOT");
	if (config.clientID) console.log(`Invite Link: https://discord.com/oauth2/authorize?client_id=${config.clientID}&scope=bot&permissions=2048`)

	client.login(config.token);
} catch (err) {
	console.log('Error logging in.', err);
	client.login(config.token);
}
client.on("error", (err) => {
	console.log('Dicord Client Error:', err);
	client.login(config.token);
})
process.on('unhandledRejection', err => { console.log('Caught Error:', err) })